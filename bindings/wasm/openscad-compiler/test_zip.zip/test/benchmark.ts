import {execFileSync, fork} from 'node:child_process';
import fs, {mkdtempSync, rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'path';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';

import {getExternalLibraries} from '../commands/util/library_compilation.js';
import {compileConsumer} from '../core/orchestrate.js';
import {setGlobalFileResolver} from '../core/state.js';
import {nodeFileResolver} from '../host/node.js';

setGlobalFileResolver(nodeFileResolver);

const argv = process.argv.slice(2);
const RUNS = parseInt(argv.find(a => /^[0-9]+$/.test(a)) ?? '5', 10);
// Cap the number of files, for a quick smoke run over a large corpus.
const LIMIT =
    parseInt(argv.find(a => a.startsWith('--limit='))?.slice(8) ?? '0', 10);
const CWD = process.cwd();
const HERE = path.dirname(fileURLToPath(import.meta.url));
const WORKER = path.resolve(HERE, './benchmark-worker.ts');
const DIR_ARG = argv.find(a => a.startsWith('--dir='))?.slice(6);
const EXAMPLES_DIR = path.resolve(CWD, DIR_ARG ?? 'test/examples');
const OUT_DIR = path.resolve(CWD, 'test/out/benchmark');
const RESULTS_PREFIX = path.resolve(CWD, 'test/out/benchmark-results');

// tsx is what lets the worker load the generated .ts modules; without it the
// fork still runs, it just cannot resolve TypeScript sources.
const WORKER_EXEC_ARGV = (() => {
  try {
    createRequire(import.meta.url).resolve('tsx');
    return ['--import', 'tsx/esm'];
  } catch {
    return [];
  }
})();

// Pinning OpenSCAD to a single core keeps the comparison honest, but taskset
// only exists on Linux.
const HAS_TASKSET = (() => {
  try {
    execFileSync('taskset', ['--version'], {stdio: 'ignore'});
    return true;
  } catch {
    return false;
  }
})();

interface Stat {
  mean: number;
  median: number;
  min: number;
  max: number;
}

interface FileResult {
  file: string;
  ourCompile: Stat|null;
  ourRun: Stat|null;
  ourTotal: Stat|null;
  openscad: Stat|null;
  speedRatio: number|null;
  error?: string;
}

interface SkippedFile {
  file: string;
  reason: string;
}

function computeStat(vals: number[]): Stat {
  const sorted = [...vals].sort((a, b) => a - b);
  const mean = vals.reduce((a, b) => a + b, 0) / vals.length;
  const mid = Math.floor(sorted.length / 2);
  const median = sorted.length % 2 === 0 ? (sorted[mid - 1] + sorted[mid]) / 2 :
                                           sorted[mid];
  return {mean, median, min: sorted[0], max: sorted[sorted.length - 1]};
}

function findScadFiles(dir: string): string[] {
  let out: string[] = [];
  for (const entry of fs.readdirSync(dir, {withFileTypes: true})) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory())
      out = out.concat(findScadFiles(fullPath));
    else if (entry.isFile() && fullPath.endsWith('.scad'))
      out.push(fullPath);
  }
  return out;
}

function isOpenscadAvailable(): boolean {
  try {
    execFileSync('openscad', ['--version'], {stdio: 'ignore'});
    return true;
  } catch {
    return false;
  }
}

function runOpenscadOnce(absFile: string): number {
  const dir = mkdtempSync(path.join(tmpdir(), 'scad-bench-'));
  try {
    const out = path.join(dir, 'out.off');
    const args = ['-o', out, '--backend=manifold', absFile];
    const env = {
      ...process.env,
      OPENSCADPATH: [
        path.dirname(absFile), CWD, process.env.OPENSCADPATH ?? ''
      ].filter(Boolean).join(path.delimiter),
    };
    const t0 = performance.now();
    if (HAS_TASKSET)
      execFileSync(
          'taskset', ['-c', '0', 'openscad', ...args], {stdio: 'ignore', env});
    else
      execFileSync('openscad', args, {stdio: 'ignore', env});
    return performance.now() - t0;
  } finally {
    rmSync(dir, {recursive: true, force: true});
  }
}

// Runs the generated module in a forked worker, which sets the runtime file and
// canvas resolvers before importing it, and returns the wall-clock time. The
// process is measured end to end so it lines up with how OpenSCAD is timed
// above.
function runCompiledOnce(outTs: string): Promise<number> {
  return new Promise((resolve, reject) => {
    const t0 = performance.now();
    const worker = fork(WORKER, [outTs], {
      execArgv: WORKER_EXEC_ARGV,
      stdio: ['ignore', 'pipe', 'pipe', 'ipc'],
      timeout: 120000,
      cwd: CWD,
    });

    let stderr = '';
    worker.stderr?.on('data', (chunk: Buffer) => {
      stderr += chunk.toString();
    });
    // The generated module may echo() to stdout; drain it so the pipe cannot
    // fill up and stall the worker.
    worker.stdout?.on('data', () => {});

    worker.on('exit', (code, signal) => {
      if (code === 0) {
        resolve(performance.now() - t0);
      } else {
        const firstLine = stderr.trim().split(/\r?\n/)[0] ?? '';
        reject(new Error(
            `worker failed (code=${code}, signal=${signal}): ${firstLine}`));
      }
    });
    worker.on('error', err => reject(err));
  });
}

// Library compilation is chatty and would drown out the per-file progress line,
// so it is muted for the duration of the timed compile.
async function silenced<T>(fn: () => Promise<T>): Promise<T> {
  const log = console.log;
  console.log = () => {};
  try {
    return await fn();
  } finally {
    console.log = log;
  }
}

// Returns a FileResult, or a SkippedFile if native OpenSCAD couldn't compile
// the file at all
async function benchmarkFile(absFile: string, openscadAvailable: boolean):
    Promise<FileResult|SkippedFile> {
  const rel = path.relative(EXAMPLES_DIR, absFile).replace(/\\/g, '/');
  const outTs = path.join(OUT_DIR, rel.replace(/\.scad$/i, '.ts'));
  fs.mkdirSync(path.dirname(outTs), {recursive: true});
  const openscadTimes: number[] = [];

  // Native OpenSCAD
  if (openscadAvailable) {
    for (let i = 0; i < RUNS; i++) {
      try {
        openscadTimes.push(runOpenscadOnce(absFile));
      } catch (err) {
        return {
          file: rel,
          reason: `openscad: ${(err as Error).message.split('\n')[0]}`
        };
      }
    }
  }

  // Compile
  const compileTimes: number[] = [];
  const errors: string[] = [];
  for (let i = 0; i < RUNS; i++) {
    try {
      const t0 = performance.now();
      const {code} = await silenced(async () => {
        const {externalLibraries, resolved} =
            await getExternalLibraries(absFile, outTs);
        return compileConsumer(
            absFile, outTs, CWD, externalLibraries, resolved);
      });
      compileTimes.push(performance.now() - t0);
      fs.writeFileSync(outTs, code);
    } catch (err) {
      errors.push(`compile: ${(err as Error).message}`);
      break;
    }
  }

  // Run the compiled output
  const runTimes: number[] = [];
  if (compileTimes.length === RUNS) {
    for (let i = 0; i < RUNS; i++) {
      try {
        runTimes.push(await runCompiledOnce(outTs));
      } catch (err) {
        errors.push(`run: ${(err as Error).message}`);
        break;
      }
    }
  }

  const ourCompile =
      compileTimes.length === RUNS ? computeStat(compileTimes) : null;
  const ourRun = runTimes.length === RUNS ? computeStat(runTimes) : null;
  const ourTotal = ourCompile && ourRun ?
      computeStat(compileTimes.map((c, i) => c + runTimes[i])) :
      null;
  const openscad =
      openscadTimes.length === RUNS ? computeStat(openscadTimes) : null;
  const speedRatio =
      openscad && ourTotal ? openscad.median / ourTotal.median : null;

  return {
    file: rel,
    ourCompile,
    ourRun,
    ourTotal,
    openscad,
    speedRatio,
    error: errors.length ? errors.join(' | ') : undefined
  };
}

function isSkipped(r: FileResult|SkippedFile): r is SkippedFile {
  return 'reason' in r;
}

function writeJson(
    results: FileResult[], skipped: SkippedFile[], openscadAvailable: boolean) {
  fs.mkdirSync(path.dirname(RESULTS_PREFIX), {recursive: true});
  fs.writeFileSync(
      `${RESULTS_PREFIX}.json`,
      JSON.stringify(
          {
            generatedAt: new Date().toISOString(),
            runsPerFile: RUNS,
            openscadAvailable,
            fileCount: results.length + skipped.length,
            benchmarkedCount: results.length,
            skippedCount: skipped.length,
            results,
            skipped,
          },
          null, 2));
}

function writeCsv(results: FileResult[]) {
  const cols = (s: Stat|null) => s ?
      [s.mean, s.median, s.min, s.max].map(n => n.toFixed(2)) :
      ['', '', '', ''];
  const header = [
    'file',         'openscad_mean', 'openscad_median', 'openscad_min',
    'openscad_max', 'compile_mean',  'compile_median',  'compile_min',
    'compile_max',  'run_mean',      'run_median',      'run_min',
    'run_max',      'total_mean',    'total_median',    'total_min',
    'total_max',    'speed_ratio',   'error',
  ].join(',');
  const lines = results.map(
      r => [r.file,
            ...cols(r.openscad),
            ...cols(r.ourCompile),
            ...cols(r.ourRun),
            ...cols(r.ourTotal),
            r.speedRatio !== null ? r.speedRatio.toFixed(2) : '',
            r.error ? `"${r.error.replace(/"/g, '""').slice(0, 300)}"` : '',
  ].join(','));
  fs.writeFileSync(
      `${RESULTS_PREFIX}.csv`, [header, ...lines].join('\n') + '\n');
}

function writeMarkdown(
    results: FileResult[], skipped: SkippedFile[], openscadAvailable: boolean) {
  const fmt = (s: Stat|null) => s ? s.median.toFixed(1) : 'ERR';
  const succeeded = results.filter(r => r.ourTotal).length;

  const lines = [
    '# Compiler Benchmark Results',
    '',
    `Generated: ${new Date().toISOString()}`,
    '',
    `Runs per file: ${RUNS} · OpenSCAD available: ${
        openscadAvailable ? 'yes' : 'no'}`,
    `Benchmarked: ${results.length} files (${
        succeeded} fully succeeded) · Skipped (openscad compile error): ${
        skipped.length}`,
    '',
    'All timings are medians in milliseconds. "Ratio" = openscad median / our-total median (>1x means we\'re faster).',
    '',
    '| File | OpenSCAD | Our compile | Our run | Our total | Ratio | Notes |',
    '|---|---:|---:|---:|---:|---:|---|',
    ...results.map(r => {
      const ratio =
          r.speedRatio !== null ? r.speedRatio.toFixed(2) + 'x' : 'n/a';
      const notes = r.error ? r.error.replace(/\|/g, '/').slice(0, 100) : '';
      return `| ${r.file} | ${openscadAvailable ? fmt(r.openscad) : 'n/a'} | ${
          fmt(r.ourCompile)} | ${fmt(r.ourRun)} | ${fmt(r.ourTotal)} | ${
          ratio} | ${notes} |`;
    }),
  ];

  if (skipped.length > 0) {
    lines.push(
        '',
        '## Skipped files (native OpenSCAD failed to compile)',
        '',
        '| File | Reason |',
        '|---|---|',
        ...skipped.map(
            s => `| ${s.file} | ${
                s.reason.replace(/\|/g, '/').slice(0, 150)} |`),
    );
  }

  fs.writeFileSync(`${RESULTS_PREFIX}.md`, lines.join('\n') + '\n');
}

function printTable(results: FileResult[], openscadAvailable: boolean) {
  const fmt = (s: Stat|null) => s ? s.median.toFixed(1) : 'ERR';
  const fileW = Math.max(4, ...results.map(r => r.file.length));
  const header =
      `${'file'.padEnd(fileW)}  ${
                             'openscad'.padStart(
                                 9)}  ${
                                   'compile'.padStart(
                                       8)}  ${'run'.padStart(9)}  ${
                                                               'total'.padStart(
                                                                   9)}  ratio`;
  console.log('--- Median timings (ms) over ' + RUNS + ' runs ---');
  console.log(header);
  console.log('-'.repeat(header.length));
  for (const r of results) {
    const ratio = r.speedRatio !== null ? r.speedRatio.toFixed(2) + 'x' : 'n/a';
    console.log(`${r.file.padEnd(fileW)}  ${
        (openscadAvailable ? fmt(r.openscad) : 'n/a').padStart(9)}  ${
        fmt(r.ourCompile).padStart(8)}  ${fmt(r.ourRun).padStart(9)}  ${
        fmt(r.ourTotal).padStart(9)}  ${ratio}`);
  }
}

async function main() {
  const openscadAvailable = isOpenscadAvailable();
  console.log(`OpenSCAD on PATH: ${openscadAvailable ? 'yes' : 'no'}`);

  const all = findScadFiles(EXAMPLES_DIR).sort();
  const files = LIMIT > 0 ? all.slice(0, LIMIT) : all;
  console.log(`Found ${all.length} .scad file(s) under ${EXAMPLES_DIR}`);
  if (files.length !== all.length)
    console.log(`Limiting to the first ${files.length}`);
  console.log(`Running ${RUNS} iterations per file per phase...`);

  const results: FileResult[] = [];
  const skipped: SkippedFile[] = [];

  for (const [i, absFile] of files.entries()) {
    const rel = path.relative(EXAMPLES_DIR, absFile).replace(/\\/g, '/');
    process.stdout.write(`[${i + 1}/${files.length}] ${rel} ... `);
    const r = await benchmarkFile(absFile, openscadAvailable);
    if (isSkipped(r)) {
      skipped.push(r);
      console.log(`SKIPPED (${r.reason.slice(0, 100)})`);
    } else {
      results.push(r);
      console.log(r.error ? `FAILED (${r.error.slice(0, 100)})` : 'ok');
    }
  }

  const succeeded = results.filter(r => r.ourTotal).length;
  console.log(
      `${results.length} file(s) benchmarked (${succeeded} fully succeeded), ${
          skipped.length} skipped due to native OpenSCAD compile errors.`);

  writeJson(results, skipped, openscadAvailable);
  writeCsv(results);
  writeMarkdown(results, skipped, openscadAvailable);
  printTable(results, openscadAvailable);

  console.log(`Wrote ${RESULTS_PREFIX}.json, ${RESULTS_PREFIX}.csv, ${
      RESULTS_PREFIX}.md`);
}

main().catch(err => {
  console.error(err);
  process.exitCode = 1;
});
