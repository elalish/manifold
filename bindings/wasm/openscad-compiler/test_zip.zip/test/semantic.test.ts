import fs from 'fs';
import {fork} from 'node:child_process';
import {existsSync, readFileSync} from 'node:fs';
import path from 'path';
import {describe, expect, test} from 'vitest';

const matchFiles = getAllFiles(path.resolve(__dirname, 'examples/echo'))
                       .filter(f => f.endsWith('.scad'));

const tsForMatch = (scadPath: string) => path.join(
    path.dirname(scadPath).replace('examples', 'out'),
    `${path.basename(scadPath, '.scad')}.ts`);

describe('echo equality', () => {
  test.each(matchFiles)('%s', async (scadPath) => {
    const tsPath = tsForMatch(scadPath);
    if (!existsSync(tsPath)) throw new Error(`No compiled file at ${tsPath}`);
    const expected = normalize(readPrecomputedEcho(scadPath), 'openscad');
    const actual = normalize(await runCompiled(tsPath), 'ts');
    expect(actual.length).toBe(expected.length);
    expected.forEach((e, i) => expectEchoEqual(actual[i], e, i));
  }, 60000);
});

function getAllFiles(dir: string): string[] {
  let results: string[] = [];

  const items = fs.readdirSync(dir, {withFileTypes: true});

  for (const item of items) {
    const fullPath = path.join(dir, item.name);

    if (item.isDirectory()) {
      results = results.concat(getAllFiles(fullPath));
    } else {
      if (fullPath.endsWith('.scad')) {
        results.push(fullPath);
      }
    }
  }

  return results;
}

function readPrecomputedEcho(scadPath: string): string[] {
  const echoDir = path.resolve(__dirname, 'echo-results');
  const relPath =
      path.relative(path.resolve(__dirname, 'examples/echo'), scadPath);
  const echoPath = path.join(echoDir, relPath.replace(/\.scad$/, '.echo'));
  if (!existsSync(echoPath)) {
    throw new Error(`No precomputed echo file at ${echoPath}`);
  }
  return readFileSync(echoPath, 'utf8').split(/\r?\n/);
}

function runCompiled(tsPath: string): Promise<string[]> {
  return new Promise((resolve, reject) => {
    const execArgv = (() => {
      try {
        require.resolve('tsx');
        return ['--import', 'tsx/esm'];
      } catch {
        return [];
      }
    })();

    const workerPath = path.resolve(__dirname, './test-echo.ts');

    const worker = fork(workerPath, [tsPath], {
      execArgv,
      stdio: ['inherit', 'pipe', 'pipe', 'ipc'],
      timeout: 60000,
    });

    let stdout = '';
    let stderr = '';

    worker.stdout?.on('data', (chunk: Buffer) => {
      stdout += chunk.toString();
    });
    worker.stderr?.on('data', (chunk: Buffer) => {
      stderr += chunk.toString();
    });

    worker.on('exit', (code, signal) => {
      if (code === 0) {
        resolve(stdout.split(/\r?\n/));
      } else {
        reject(new Error(
            `Compiled run failed (code=${code}, signal=${signal})\n` +
            `file: ${tsPath}\n` +
            `stderr: ${stderr}\n` +
            `stdout: ${stdout}`));
      }
    });

    worker.on('error', (err) => {
      reject(new Error(
          `Worker failed: ${err.message}\nworkerPath: ${workerPath}`));
    });
  });
}

function normalize(lines: string[], source: 'openscad'|'ts'): Tok[][] {
  const records =
      source === 'openscad' ? echoRecordsOpenscad(lines) : echoRecordsTs(lines);
  return records.map((r) => expandRanges(lexLine(r)));
}

function echoRecordsOpenscad(lines: string[]): string[] {
  const out: string[] = [];
  let cur: string|null = null;
  for (const raw of lines) {
    const l = raw.replace(/\r$/, '');
    if (l.startsWith('ECHO: ')) {
      if (cur) out.push(cur);
      cur = l.slice(6);
    } else if (/^(WARNING|ERROR|TRACE|DEPRECATED|UI-WARNING|UI-ERROR):/.test(
                   l)) {
      if (cur) out.push(cur);
      cur = null;
    } else if (cur !== null) {
      cur += '\n' + l;
    }
  }
  if (cur) out.push(cur);
  return out;
}

function echoRecordsTs(lines: string[]): string[] {
  return lines.map((l) => l.replace(/\r$/, '')).filter((l) => l !== '');
}

// numeric token as number and anything else as string
type Tok = number|string;

const NUMERIC = /^[-+]?(\d+\.?\d*|\.\d+)([eE][-+]?\d+)?$/;

const LITERAL_MAP: Record<string, string> = {
  undefined: 'undef',
  null: 'undef',
  undef: 'undef',
  NaN: 'undef',
  nan: 'undef',
  Infinity: 'inf',
  '-Infinity': '-inf',
};

function lexLine(line: string): Tok[] {
  const s = line.replace(/\\[trn]/g, ' ')
                .replace(/[\t\r\n]/g, ' ')
                .replace(/\\/g, '')
                .replace(/["']/g, '');
  const seps = ' \t,[]:=';
  const toks: Tok[] = [];
  let i = 0;
  while (i < s.length) {
    const ch = s[i]!;
    if (ch === ' ' || ch === '\t' || ch === ',') {
      i++;
      continue;
    }
    if (ch === '[' || ch === ']' || ch === ':' || ch === '=') {
      toks.push(ch);
      i++;
      continue;
    }
    let j = i;
    while (j < s.length && !seps.includes(s[j]!)) j++;
    const word = s.slice(i, j);
    i = j;
    if (word === '') continue;
    toks.push(NUMERIC.test(word) ? Number(word) : (LITERAL_MAP[word] ?? word));
  }
  return toks;
}

// expand OpenSCAD range syntax to match compiled range output
function expandRanges(toks: Tok[]): Tok[] {
  const out: Tok[] = [];
  let i = 0;
  while (i < toks.length) {
    if (toks[i] === '[' && typeof toks[i + 1] === 'number' &&
        toks[i + 2] === ':' && typeof toks[i + 3] === 'number' &&
        toks[i + 4] === ':' && typeof toks[i + 5] === 'number' &&
        toks[i + 6] === ']') {
      const start = toks[i + 1] as number;
      const step = toks[i + 3] as number;
      const end = toks[i + 5] as number;
      out.push('[');
      if (step > 0)
        for (let v = start; v <= end; v += step) out.push(v);
      else if (step < 0)
        for (let v = start; v >= end; v += step) out.push(v);
      out.push(']');
      i += 7;
    } else {
      out.push(toks[i]!);
      i++;
    }
  }
  return out;
}

// compare one echo line, numbers with a relative tolerance
function expectEchoEqual(a: Tok[], e: Tok[], lineIdx: number) {
  expect(
      a.length,
      `line ${lineIdx} token count\n  ts: ${JSON.stringify(a)}\n  os: ${
          JSON.stringify(e)}`)
      .toBe(e.length);
  a.forEach((tok, i) => {
    const want = e[i]!;
    if (typeof tok === 'number' && typeof want === 'number') {
      const tol = 1e-5 * Math.max(1, Math.abs(tok), Math.abs(want));
      expect(
          Math.abs(tok - want),
          `line ${lineIdx} token ${i}: ${tok} vs ${want}`,
          )
          .toBeLessThanOrEqual(tol);
    } else {
      expect(tok, `line ${lineIdx} token ${i}`).toEqual(want);
    }
  });
}