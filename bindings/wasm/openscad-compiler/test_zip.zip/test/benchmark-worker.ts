import fs from 'fs';
import path from 'path';
import {fileURLToPath, pathToFileURL} from 'url';
import {createCanvas, Image} from 'canvas';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const RUNTIME = path.resolve(HERE, '../runtime/runtime.js');

const args = process.argv.slice(2);
// Report the init / logic / geometry split as JSON instead of just running.
const PHASES = args.includes('--phases');
const filename = args.find(a => !a.startsWith('--'));

async function run() {
  if (!filename) {
    process.stderr.write('No filename argument provided\n');
    process.exit(1);
  }

  // Import the runtime to set resolvers before loading the compiled module
  const host = await import('../runtime/utils/host');
  host.setRunTimeFileResolver({
    exists(filePath: string): boolean {
      return fs.existsSync(filePath);
    },
    readText(filePath: string): string | null {
      try { return fs.readFileSync(filePath, 'utf8'); } catch { return null; }
    },
    readBinary(filePath: string): Buffer | null {
      try { return fs.readFileSync(filePath); } catch { return null; }
    },
    readDir(dirPath: string): string[] {
      try { return fs.readdirSync(dirPath); } catch { return []; }
    },
  });

  host.setRunTimeCanvasResolver({
    createCanvas(width: number, height: number) {
      return createCanvas(width, height);
    },
    image() {
      return new Image();
    },
  });

  const fileUrl = pathToFileURL(path.resolve(filename)).href;

  // Runtime init: wasm boot and wasm.setup(). Pulling it in up front keeps it
  // out of the logic measurement below; the module import then finds it warm in
  // the module cache.
  const t0 = performance.now();
  if (PHASES) await import(pathToFileURL(RUNTIME).href);
  const t1 = performance.now();

  // Logic: the generated file's top-level body. Module and function evaluation,
  // for-loops, list comprehensions, and the construction of the Manifold
  // operation DAG.
  const mod = await import(fileUrl);
  const t2 = performance.now();

  // Geometry: force the lazy DAG to flush. `result` may be a Manifold (3D) or a
  // CrossSection (2D), and echo-only files have neither.
  const result = mod.result;
  if (result && typeof result.getMesh === 'function') {
    result.getMesh();
  } else if (result && typeof result.toPolygons === 'function') {
    result.toPolygons();
  }
  const t3 = performance.now();

  if (PHASES) {
    const sample = {ok: true, init: t1 - t0, logic: t2 - t1, geometry: t3 - t2};
    // Prefer the IPC channel: the module under test may echo() to stdout, and
    // that output would otherwise have to be told apart from the result.
    if (process.send) {
      await new Promise<void>(resolve => process.send!(sample, () => resolve()));
    } else {
      process.stdout.write(JSON.stringify(sample));
    }
  }
  process.exit(0);
}

run().catch(e => {
  process.stderr.write(`Worker error: ${String(e)}\n${e?.stack ?? ''}\n`);
  process.exit(1);
});
