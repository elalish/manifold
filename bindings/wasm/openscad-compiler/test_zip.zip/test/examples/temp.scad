function factorial(n) =
    n <= 1
        ? 1
        : n * factorial(n - 1);

echo(factorial(1000));