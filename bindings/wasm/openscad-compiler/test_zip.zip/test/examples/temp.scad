function f3a(a) = a <= 0 ? 0 : a + f3a(a - 1);

n = 100000;

echo(f3a(n));
