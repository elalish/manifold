text();
text("");
