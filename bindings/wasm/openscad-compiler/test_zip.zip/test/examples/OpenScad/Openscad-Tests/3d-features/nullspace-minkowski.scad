// Volume: 1, SurfaceArea: 6
minkowski() {
    intersection() {
        translate([-2,0,0]) cube(1);
        translate([2,0,0]) cube(1);
    }
    cube();
}
