cube(10);
