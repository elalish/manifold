square(10);
