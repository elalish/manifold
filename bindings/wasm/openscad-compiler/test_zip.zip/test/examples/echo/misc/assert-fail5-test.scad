assert(message = "assert-message");
