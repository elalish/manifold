linear_extrude(h=1) {
    square(0);
    circle(0);
    polygon();
}

cube(0);
sphere(0);
cylinder(0);
polyhedron();
surface();
rotate_extrude();
linear_extrude();
translate();
color();
hull();
minkowski();
union();
difference();
intersection();
render();
projection();
if(1) { }
intersection_for();
for();
