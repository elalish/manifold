p = PI; echo(p);
