echo ("A");
echo ("B");
