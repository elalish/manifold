union() {
  polyhedron();
  polyhedron();
}
