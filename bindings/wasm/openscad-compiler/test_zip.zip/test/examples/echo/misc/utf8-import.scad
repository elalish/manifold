// Test various imports of files with non-ASCII names.
// Note that the resulting image is actually of no interest.
// However, any interesting errors in these imports happen
// during geometry processing, so we can't just be an
// echo, csg, or ast test - we have to actually do the
// geometry processing.
// removed import statements as import is not supported by the compiler

// These fail on the MXE-MINGW64 build because its fopen() can't handle UTF-8 paths.
surface("../assets/☠.dat");
surface("../assets/☠-2D.png");

// This (or another test) should test include<>, use<*.scad>, and use<*.ttf>.
// They all fail in various ways.
