echo("after");
after = true;
