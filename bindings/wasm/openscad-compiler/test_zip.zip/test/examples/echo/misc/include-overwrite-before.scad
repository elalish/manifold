echo("before");
before = true;
