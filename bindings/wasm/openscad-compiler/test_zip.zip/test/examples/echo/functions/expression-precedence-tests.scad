// Can't output the actual value as the order of evaluation
// is undefined, so it can change depending on the C++ compiler
// used to compile OpenSCAD
function f(x) = echo("-") x;

// associativity
echo(assoc_right_unary = 4---3);

echo(assoc_left_addsub = 2 - 3 + 4);
echo(assoc_left_subadd = 2 + 3 - 4);
echo(assoc_left_muldiv = 2 * 3 / 4);
echo(assoc_left_ltgt   = 3 < 4 > 5);
echo(assoc_left_eqne   = true == true != false);
echo(assoc_left_and    = true && true && false);
echo(assoc_left_or     = true || true || false);

// precedence
echo(prec_andor = true && true || true && false);
echo(prec_orand = false || false && false || true);

echo(prec_gtadd = 3 + 2 > 4);
echo(prec_addgt = 5 > 2 + 4);

echo(prec_addmul = 2 + 3 * 4);
echo(prec_muladd = 2 * 3 + 4);
echo(prec_submul = 2 - 3 * 4);
echo(prec_mulsub = 2 * 3 - 4);
echo(prec_addmod = 2 + 3 % 4);
echo(prec_modadd = 2 % 3 + 4);

echo(prec_unarysub = 2 / -2 / 2);
echo(prec_unaryadd = 2 / +2 / 2);

// short circuit
echo(sc_or = f(false) || f(true) || f(true));
echo(sc_and = f(true) && f(false) && f(false));
echo(sc_ternary_false = f(false) ? f("yes") : f("no"));
echo(sc_ternary_true = f(true) ? f("yes") : f("no"));
