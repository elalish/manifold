a = "text;

text(a);