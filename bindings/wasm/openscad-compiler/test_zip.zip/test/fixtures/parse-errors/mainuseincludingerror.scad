use<mainincludingerror.scad>
errmod();