import { vfs } from '../vfs/vfs'
import { createCanvas, Image } from 'canvas';
import {fileURLToPath, pathToFileURL} from 'url';
import path from 'path-browserify';

async function main () {
  const filename = "./test/out/temp_text.ts";

  const host = await import('../runtime/utils/host');
  host.setRunTimeFileResolver({
    exists(filePath: string): boolean {
      return vfs.existsSync(filePath);
    },
    readText(filePath: string): string | null {
      try { return vfs.readFileSync(filePath, 'utf8') as string; } catch { return null; }
    },
    readBinary(filePath: string): Buffer | null {
      try { return vfs.readFileSync(filePath); } catch { return null; }
    },
    writeFile(filePath: string, blobBuffer: Buffer) {
      try { return vfs.writeFileSync(filePath, blobBuffer); } catch { return null; }
    },
    readDir(dirPath: string): string[] {
      try { return vfs.readdirSync(dirPath); } catch { return []; }
    },
  });

  host.setRunTimeCanvasResolver({
    createCanvas(width: number, height: number) {
      return createCanvas(width, height);
    },
    image() {
      return new Image();
    },
  });

  const requestedFontDir = '/fonts'
  if (!vfs.existsSync(requestedFontDir)) {
    // crate the dir
    vfs.mkdirSync(requestedFontDir);
  }
  host.setEnvironmentResolver({
    fontDir: requestedFontDir,
    mode: 'web'
  });

  const absolutePath = path.resolve(filename);
  const fileUrl = pathToFileURL(absolutePath).href;

  const mod = await import(fileUrl);

  if (!mod.result) {
    throw new Error(`Module has no 'result' export: ${filename}`);
  }

  const result = {
    volume: mod.result.volume() as number,
    surfaceArea: mod.result.surfaceArea() as number,
  };
}

main();