import path from 'path';
import {pathToFileURL} from 'url';
import fs from 'fs';
import { createCanvas, Image } from 'canvas';

const filename = process.argv[2];

async function run() {
  if (!filename) {
    process.stderr.write('No filename argument provided\n');
    process.exit(1);
  }

  // Import the runtime to set resolvers before loading the compiled module
  const host = await import('../runtime/utils/host');
  host.setRunTimeFileResolver({
    exists(filePath: string): boolean {
      return fs.existsSync(filePath);
    },
    readText(filePath: string): string | null {
      try { return fs.readFileSync(filePath, 'utf8'); } catch { return null; }
    },
    readBinary(filePath: string): Buffer | null {
      try { return fs.readFileSync(filePath); } catch { return null; }
    },
    readDir(dirPath: string): string[] {
      try { return fs.readdirSync(dirPath); } catch { return []; }
    },
  });

  host.setRunTimeCanvasResolver({
    createCanvas(width: number, height: number) {
      return createCanvas(width, height);
    },
    image() {
      return new Image();
    },
  });

  const absolutePath = path.resolve(filename);
  const fileUrl = pathToFileURL(absolutePath).href;

  const mod = await import(fileUrl);

  if (!mod.result) {
    throw new Error(`Module has no 'result' export: ${filename}`);
  }

  const result = {
    volume: mod.result.volume() as number,
    surfaceArea: mod.result.surfaceArea() as number,
  };

  process.stdout.write(JSON.stringify(result));
  process.exit(0);
}

run().catch(e => {
  process.stderr.write(`Worker error: ${String(e)}\n${e?.stack ?? ''}\n`);
  process.exit(1);
});